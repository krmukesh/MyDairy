package com.mobilophilia.mydairy.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.common.Constants;
import com.mobilophilia.mydairy.common.Util;

/**
 * Created by yogen on 12-07-2017.
 */

public class SplashView extends Activity {

    private static boolean splashLoaded = false;

    //http://www.androidhive.info/2015/04/android-getting-started-with-material-design/
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash);


        new Handler().postDelayed(new Runnable() {
            public void run() {
                SharedPreferences sharedPreferences = getSharedPreferences(Constants.SP_MY_DAIRY_MK, MODE_PRIVATE);
                String token = sharedPreferences.getString(Constants.SP_AGENT_TOKEN_KEY, null);

                if (!Util.isEmpty(token)) {
                    Intent intent = new Intent(SplashView.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(SplashView.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }

              /*  Intent intent = new Intent(SplashView.this, MainActivity.class);
                startActivity(intent);
                finish();*/
            }
        }, 2000);
    }
}
