package com.mobilophilia.mydairy.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.database.EnterNameEntry;

import java.util.List;

/**
 * Created by Hanji on 7/22/2017.
 */

public class CustomerListAdapter extends RecyclerView.Adapter<CustomerListAdapter.MyViewHolder> {

    private List<EnterNameEntry> moviesList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView customerCode, customerName, customerPhone, type;

        public MyViewHolder(View view) {
            super(view);
            customerCode = (TextView) view.findViewById(R.id.customer_code);
            customerName = (TextView) view.findViewById(R.id.costomer_name_lv);
            customerPhone = (TextView) view.findViewById(R.id.customer_phone);
            type = (TextView) view.findViewById(R.id.customer_type);
        }
    }

    public CustomerListAdapter(List<EnterNameEntry> moviesList) {
        this.moviesList = moviesList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_customer_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        EnterNameEntry customer = moviesList.get(position);
        holder.customerCode.setText("Code : " + customer.getNameCode());
        holder.customerName.setText("" + customer.getEnterName());
        holder.customerPhone.setText("" + customer.getPhoneNo());
        holder.type.setText("Type : " + getTypeFromSelected(customer.getType()));
    }


    private String getTypeFromSelected(int positionDropDown) {
        String type = "";
        if (positionDropDown == 0) {
            type = "Cow";
        } else if (positionDropDown == 1) {
            type = "Buffalo";
        }
        return type;
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}