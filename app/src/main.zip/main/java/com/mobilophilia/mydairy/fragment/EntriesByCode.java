package com.mobilophilia.mydairy.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.adapter.EntriesListByCodeAdapter;
import com.mobilophilia.mydairy.common.RecyclerItemClickListener;
import com.mobilophilia.mydairy.database.DBHelper;
import com.mobilophilia.mydairy.database.MyEntries;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mukesh on 04/08/17.
 */

public class EntriesByCode extends Fragment {

    private List<MyEntries> myEntries = new ArrayList<>();
    private RecyclerView recyclerView;
    private EntriesListByCodeAdapter mAdapter;
    private DBHelper dbHelper;
    int id ;

    public EntriesByCode() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_entry_list, container, false);

        dbHelper = new DBHelper(getActivity());
        myEntries.clear();

        Bundle bundle = this.getArguments();
        if (bundle != null) {
            id = bundle.getInt("ID");
        }

        myEntries = dbHelper.getListOfEntriesByCode(id);

        recyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view_entry_list);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        mAdapter = new EntriesListByCodeAdapter(myEntries);
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // TODO Handle item click
                    }
                })
        );

        return rootView;
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
