package com.mobilophilia.mydairy.common;

import android.content.Context;
import android.content.SharedPreferences;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.BinaryHttpResponseHandler;
import com.loopj.android.http.FileAsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;


/**
 * Created by akshit_sharma on 24/8/15.
 */
public class RestClient {

    public static final AsyncHttpClient client = new AsyncHttpClient();



    public static void get(String url, Header[] header, AsyncHttpResponseHandler responseHandler) {
        client.get(null, url, header, null, responseHandler);
        client.setTimeout(30000);
    }
    public static void post(Context context, String url, Header[] headers, StringEntity entity, AsyncHttpResponseHandler responseHandler) {
        client.post(context, url, headers, entity, "application/json", responseHandler);
        client.setTimeout(30000);
    }

    public static void getFile(Context context, String url, Header[] headers, RequestParams requestParams, FileAsyncHttpResponseHandler responseHandler) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.SP_MY_DAIRY_MK, context.MODE_PRIVATE);
        String token = sharedPreferences.getString(Constants.SP_AGENT_TOKEN_KEY, null);
        client.addHeader("token", token);
        client.get(context, url, headers, requestParams, responseHandler);
        client.setTimeout(30000);
    }


    public static void getFileBinary(Context context, String url, Header[] headers, RequestParams requestParams, BinaryHttpResponseHandler responseHandler) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.SP_MY_DAIRY_MK, context.MODE_PRIVATE);
        String token = sharedPreferences.getString(Constants.SP_AGENT_TOKEN_KEY, null);
        client.addHeader("token", token);
        client.get(context, url, headers, requestParams, responseHandler);
        client.setTimeout(30000);
    }

    public static void postWithHeader(Context context, String url, StringEntity entity, AsyncHttpResponseHandler responseHandler) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.SP_MY_DAIRY_MK, context.MODE_PRIVATE);
        String token = sharedPreferences.getString(Constants.SP_AGENT_TOKEN_KEY, null);
        client.addHeader("token", token);
        client.post(context, url, entity, "application/json", responseHandler);
        client.setTimeout(30000);
    }

}
