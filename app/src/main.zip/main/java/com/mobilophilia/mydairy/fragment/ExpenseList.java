package com.mobilophilia.mydairy.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.adapter.ExpenseAdapter;
import com.mobilophilia.mydairy.database.DBHelper;
import com.mobilophilia.mydairy.database.ExpenseBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mukesh on 16/08/17.
 */

public class ExpenseList extends Fragment {

    private List<ExpenseBean> expenseList= new ArrayList<>();
    private RecyclerView recyclerView;
    private ExpenseAdapter mAdapter;
    private DBHelper dbHelper;

    public ExpenseList() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_expenses_list, container, false);

        dbHelper = new DBHelper(getActivity());
        expenseList.clear();
        expenseList = dbHelper.getAllExpenses();

        recyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view_entry_list);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        mAdapter = new ExpenseAdapter(expenseList);
        recyclerView.setAdapter(mAdapter);


        return rootView;
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}