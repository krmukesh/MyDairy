package com.mobilophilia.mydairy.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.Selection;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.activity.PriceTableActivity;
import com.mobilophilia.mydairy.common.Constants;
import com.mobilophilia.mydairy.common.Util;
import com.mobilophilia.mydairy.database.DBHelper;
import com.mobilophilia.mydairy.database.SetPriceEntry;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yogen on 18-07-2017.
 */

public class SetPriceFragment extends Fragment implements View.OnClickListener {
    private View rootView;
    private Button btnSave;
    private Button btnCancel;
    private TableLayout tableLayoutView;

    private EditText lowFat;
    private EditText highFat;
    private EditText lowSnf;
    private EditText highSnf;
    private EditText startPrice;
    private EditText interval;

    private DBHelper dbHelper;
    private int recordId = 0;
    private int mtype = 0, mTiming = 0;
    private List<SetPriceEntry> savedPrice = new ArrayList<>();
    private LinearLayout llLable;
    private Spinner mySpinner_cb;
    private Spinner mySpinner_me;
    private String errorMessage = "";

    public SetPriceFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_setprice, container, false);
        llLable = (LinearLayout) rootView.findViewById(R.id.ll_lable);


        dbHelper = new DBHelper(getActivity());
        btnSave = (Button) rootView.findViewById(R.id.btn_save);
        btnCancel = (Button) rootView.findViewById(R.id.btn_cancel);

        lowFat = (EditText) rootView.findViewById(R.id.edt_low_fat);
        highFat = (EditText) rootView.findViewById(R.id.edt_high_fat);
        lowSnf = (EditText) rootView.findViewById(R.id.edt_low_snf);
        highSnf = (EditText) rootView.findViewById(R.id.edt_high_snf);
        startPrice = (EditText) rootView.findViewById(R.id.edt_strat_price);
        interval = (EditText) rootView.findViewById(R.id.edt_interval);


        Util.setBlankAndIsEnable(lowFat, true);
        Util.setBlankAndIsEnable(highFat, false);
        Util.setBlankAndIsEnable(lowSnf, false);
        Util.setBlankAndIsEnable(highSnf, false);
        Util.setBlankAndIsEnable(startPrice, false);
        Util.setBlankAndIsEnable(interval, false);
        Util.iSenableButton(getActivity(), btnSave, false);


        tableLayoutView = (TableLayout) rootView.findViewById(R.id.table_view_added);

        btnSave.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

        savedPrice = dbHelper.getAllSetPrice();
        if (savedPrice.size() > 0) {
            llLable.setVisibility(View.VISIBLE);
            makeTableforEnterData(savedPrice);
        } else {
            llLable.setVisibility(View.GONE);
            llLable.setVisibility(View.GONE);
        }

        mySpinner_cb = (Spinner) rootView.findViewById(R.id.spinner_type_cb);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, R.id.sp_item, Constants.type);
        mySpinner_cb.setAdapter(adapter);
        mySpinner_cb.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mtype = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        mySpinner_me = (Spinner) rootView.findViewById(R.id.spinner_me);
        ArrayAdapter<String> adapterMe = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, R.id.sp_item, Constants.timing);
        mySpinner_me.setAdapter(adapterMe);
        mySpinner_me.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mTiming = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        interval.setText("0.");
        Selection.setSelection(interval.getText(), interval.getText().length());
        interval.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().startsWith("0.")) {
                    interval.setText("0.");
                    Selection.setSelection(interval.getText(), interval.getText().length());
                }

                String intervalD = interval.getText().toString();
                if (intervalD.length() > 2) {
                    Double lP = Double.parseDouble(intervalD);
                    if (lP < 0.1) {
                        errorMessage = Constants.ERROR_INTERVAL_BLANK;
                        errorMessage(errorMessage);
                        Util.iSenableButton(getActivity(), btnSave, false);
                    } else {
                        Util.iSenableButton(getActivity(), btnSave, true);
                    }
                }else {
                    Util.iSenableButton(getActivity(), btnSave, false);
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


// Low Fat
        lowFat.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String fat = lowFat.getText().toString();
                if (!Util.isEmpty(fat)) {
                    Double lFat = Double.parseDouble(fat);
                    if (lFat > 11) {

                        Util.setBlankAndIsEnable(highFat, false);
                        Util.setBlankAndIsEnable(lowSnf, false);
                        Util.setBlankAndIsEnable(highSnf, false);
                        Util.setBlankAndIsEnable(startPrice, false);
                        Util.setBlankAndIsEnable(interval, false);
                        Util.iSenableButton(getActivity(), btnSave, false);
                        errorMessage = Constants.ERROR_FAT;
                        errorMessage(errorMessage);

                    } else {
                        Util.setBlankAndIsEnable(highFat, true);
                        Util.setBlankAndIsEnable(lowSnf, false);
                        Util.setBlankAndIsEnable(highSnf, false);
                        Util.setBlankAndIsEnable(startPrice, false);
                        Util.setBlankAndIsEnable(interval, false);
                        Util.iSenableButton(getActivity(), btnSave, false);
                    }
                } else {
                    errorMessage = Constants.ERROR_FAT_LOW_BLANK;
                    errorMessage(errorMessage);

                    Util.setBlankAndIsEnable(highFat, false);
                    Util.setBlankAndIsEnable(lowSnf, false);
                    Util.setBlankAndIsEnable(highSnf, false);
                    Util.setBlankAndIsEnable(startPrice, false);
                    Util.setBlankAndIsEnable(interval, false);
                    Util.iSenableButton(getActivity(), btnSave, false);

                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        // High Fat
        highFat.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String fat = highFat.getText().toString();
                if (!Util.isEmpty(fat)) {
                    Double lFat = Double.parseDouble(fat);
                    if (lFat > 11) {
                        errorMessage = Constants.ERROR_FAT;
                        errorMessage(errorMessage);

                        Util.setBlankAndIsEnable(lowSnf, false);
                        Util.setBlankAndIsEnable(highSnf, false);
                        Util.setBlankAndIsEnable(startPrice, false);
                        Util.setBlankAndIsEnable(interval, false);
                        Util.iSenableButton(getActivity(), btnSave, false);

                    } else {
                        Util.setBlankAndIsEnable(lowSnf, true);
                        Util.setBlankAndIsEnable(highSnf, false);
                        Util.setBlankAndIsEnable(startPrice, false);
                        Util.setBlankAndIsEnable(interval, false);
                        Util.iSenableButton(getActivity(), btnSave, false);
                    }
                } else {
                    errorMessage = Constants.ERROR_FAT_HIGH_BLANK;
                    errorMessage(errorMessage);

                    Util.setBlankAndIsEnable(lowSnf, false);
                    Util.setBlankAndIsEnable(highSnf, false);
                    Util.setBlankAndIsEnable(startPrice, false);
                    Util.setBlankAndIsEnable(interval, false);
                    Util.iSenableButton(getActivity(), btnSave, false);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        // Low SNF
        lowSnf.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String snf = lowSnf.getText().toString();
                if (!Util.isEmpty(snf)) {
                    Double lFat = Double.parseDouble(snf);
                    if (lFat > 13) {
                        errorMessage = Constants.ERROR_SNF;
                        errorMessage(errorMessage);

                        Util.setBlankAndIsEnable(highSnf, false);
                        Util.setBlankAndIsEnable(startPrice, false);
                        Util.setBlankAndIsEnable(interval, false);
                        Util.iSenableButton(getActivity(), btnSave, false);

                    } else {
                        Util.setBlankAndIsEnable(highSnf, true);
                        Util.setBlankAndIsEnable(startPrice, false);
                        Util.setBlankAndIsEnable(interval, false);
                        Util.iSenableButton(getActivity(), btnSave, false);
                    }
                } else {
                    errorMessage = Constants.ERROR_SNF_LOW_BLANK;
                    errorMessage(errorMessage);

                    Util.setBlankAndIsEnable(highSnf, false);
                    Util.setBlankAndIsEnable(startPrice, false);
                    Util.setBlankAndIsEnable(interval, false);
                    Util.iSenableButton(getActivity(), btnSave, false);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        // High SNF
        highSnf.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String snf = highSnf.getText().toString();
                if (!Util.isEmpty(snf)) {
                    Double lFat = Double.parseDouble(snf);
                    if (lFat > 13) {
                        errorMessage = Constants.ERROR_SNF;
                        errorMessage(errorMessage);

                        Util.setBlankAndIsEnable(startPrice, false);
                        Util.setBlankAndIsEnable(interval, false);
                        Util.iSenableButton(getActivity(), btnSave, false);

                    } else {
                        Util.setBlankAndIsEnable(startPrice, true);
                        Util.setBlankAndIsEnable(interval, false);
                        Util.iSenableButton(getActivity(), btnSave, false);
                    }
                } else {
                    errorMessage = Constants.ERROR_SNF_HIGH_BLANK;
                    errorMessage(errorMessage);
                    Util.setBlankAndIsEnable(startPrice, false);
                    Util.setBlankAndIsEnable(interval, false);
                    Util.iSenableButton(getActivity(), btnSave, false);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });


        // Set Price
        startPrice.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String price = startPrice.getText().toString();
                if (!Util.isEmpty(price)) {
                    Double priceD = Double.parseDouble(price);
                    if (priceD < 1) {
                        errorMessage = Constants.ERROR_PRICE;
                        errorMessage(errorMessage);

                        Util.setBlankAndIsEnable(interval, false);
                        Util.iSenableButton(getActivity(), btnSave, false);

                    } else {
                        Util.setBlankAndIsEnable(interval, true);
                        Util.iSenableButton(getActivity(), btnSave, false);
                    }
                } else {
                    errorMessage = Constants.ERROR_PRICE_BLANK;
                    errorMessage(errorMessage);

                    Util.setBlankAndIsEnable(interval, false);
                    Util.iSenableButton(getActivity(), btnSave, false);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });


        // Inflate the layout for this fragment
        return rootView;
    }

    private void makeTableforEnterData(List<SetPriceEntry> priceList) {

        if (priceList.size() > 0) {
            llLable.setVisibility(View.VISIBLE);
        } else {
            llLable.setVisibility(View.GONE);
        }
        //
        for (int i = 0; i < priceList.size(); i++) {
            LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(getActivity().LAYOUT_INFLATER_SERVICE);
            LinearLayout row = (LinearLayout) inflater.inflate(R.layout.row_price, null);
            if (i % 2 == 0) {
                row.setBackgroundColor(getResources().getColor(R.color.con_theme));
            } else {
                row.setBackgroundColor(getResources().getColor(R.color.back_theme));
            }
            final SetPriceEntry spe = priceList.get(i);

            final TextView lfat = (TextView) row.findViewById(R.id.lv1_one);
            lfat.setText(String.format("%.1f", spe.getLowFat()));

            final TextView hfat = (TextView) row.findViewById(R.id.lv1_two);
            hfat.setText(String.format("%.1f", spe.getHighFat()));

            final TextView lsnf = (TextView) row.findViewById(R.id.lv1_three);
            lsnf.setText(String.format("%.1f", spe.getLowSnf()));

            final TextView hsnf = (TextView) row.findViewById(R.id.lv1_four);
            hsnf.setText(String.format("%.1f", spe.getHighSnf()));

            final TextView sprice = (TextView) row.findViewById(R.id.lv1_five);
            sprice.setText(String.format("%.1f", spe.getStartPrice()));

            final TextView mInterval = (TextView) row.findViewById(R.id.lv1_six);
            mInterval.setText(String.format("%.1f", spe.getInterval()));

            final TextView typeTime = (TextView) row.findViewById(R.id.lv1_type_time);
            typeTime.setText(getTypeTimeToSelection(spe.getType(), spe.getTime()));

            tableLayoutView.addView(row);

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    recordId = spe.getId();
                    Intent priceIntent = new Intent(getActivity(), PriceTableActivity.class);
                    priceIntent.putExtra(Constants.RECORD_ID_TABLE, recordId);
                    startActivity(priceIntent);
                }
            });

            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    recordId = spe.getId();
                    lowFat.setText(lfat.getText());
                    highFat.setText(hfat.getText());
                    lowSnf.setText(lsnf.getText());
                    highSnf.setText(hsnf.getText());
                    startPrice.setText(sprice.getText());
                    interval.setText(mInterval.getText());
                    btnSave.setText("Update");

                    mtype = spe.getType();
                    mTiming = spe.getTime();

                    mySpinner_cb.setSelection(mtype);
                    mySpinner_me.setSelection(mTiming);
                    Util.iSenableButton(getActivity(), btnSave, true);
                    lowFat.requestFocus();
                    return true;
                }
            });
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId() /*to get clicked view id**/) {
            case R.id.btn_save:
                if (btnSave.getText().toString().equalsIgnoreCase("Save")) {
                    Util.hideKeyboard(getActivity());
                    saveEntry(0);
                } else {
                    Util.hideKeyboard(getActivity());
                    saveEntry(recordId);
                }
                break;
            case R.id.btn_cancel:
                Util.hideKeyboard(getActivity());
                reSetField();
                break;

            default:
                break;
        }
    }

    private void saveEntry(int id) {
        if (feildValidation()) {
            saveData(id);
        } else {
            errorMessage = Constants.FIELD_MAINDATORY;
            errorMessage(errorMessage);
        }
    }

    private void saveData(int updateId) {

        SetPriceEntry spe = new SetPriceEntry();
        spe.setLowFat(Double.parseDouble(lowFat.getText().toString()));
        spe.setHighFat(Double.parseDouble(highFat.getText().toString()));
        spe.setLowSnf(Double.parseDouble(lowSnf.getText().toString()));
        spe.setHighSnf(Double.parseDouble(highSnf.getText().toString()));
        spe.setStartPrice(Double.parseDouble(startPrice.getText().toString()));
        spe.setInterval(Double.parseDouble(interval.getText().toString()));
        spe.setType(mtype);
        spe.setTime(mTiming);

        if (updateId == 0) {
            dbHelper.createSetPriceEntry(spe);
        } else {
            spe.setId(recordId);
            dbHelper.updatePriceWithId(spe);
        }
        savedPrice = dbHelper.getAllSetPrice();
        if (savedPrice.size() > 0) {
            tableLayoutView.removeAllViews();
            makeTableforEnterData(savedPrice);
        }
        reSetField();
    }


    private boolean feildValidation() {
        boolean rtn = true;
        if (Util.isEmpty(lowFat.getText().toString())) {
            rtn = false;
        } else if (Util.isEmpty(highFat.getText().toString())) {
            rtn = false;
        } else if (Util.isEmpty(lowSnf.getText().toString())) {
            rtn = false;
        } else if (Util.isEmpty(highSnf.getText().toString())) {
            rtn = false;
        } else if (Util.isEmpty(startPrice.getText().toString())) {
            rtn = false;
        } else if (Util.isEmpty(interval.getText().toString())) {
            rtn = false;
        }
        return rtn;
    }

    private void errorMessage(String message) {
        Snackbar.make(rootView, "" + message, Snackbar.LENGTH_LONG).show();
    }

    private void reSetField() {

        Util.setBlankAndIsEnable(lowFat, true);
        Util.setBlankAndIsEnable(highFat, false);
        Util.setBlankAndIsEnable(lowSnf, false);
        Util.setBlankAndIsEnable(highSnf, false);
        Util.setBlankAndIsEnable(startPrice, false);
        Util.setBlankAndIsEnable(interval, false);
        Util.iSenableButton(getActivity(), btnSave, false);
        btnSave.setText("Save");
        recordId = 0;
        mtype = 0;
        mTiming = 0;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    public static String getTypeTimeToSelection(int type, int time) {
        String txtTimeTye = "";
        if (type == 0 && time == 0) {
            txtTimeTye = "C-M";
        } else if (type == 0 && time == 1) {
            txtTimeTye = "C-E";
        } else if (type == 1 && time == 0) {
            txtTimeTye = "B-M";
        } else if (type == 1 && time == 1) {
            txtTimeTye = "B-E";
        }
        return txtTimeTye;
    }
}
