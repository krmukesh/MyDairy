package com.mobilophilia.mydairy.activity;

/**
 * Created by yogen on 12-07-2017.
 */

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.common.Constants;
import com.mobilophilia.mydairy.common.Log;
import com.mobilophilia.mydairy.common.Util;
import com.mobilophilia.mydairy.drawer.FragmentDrawer;
import com.mobilophilia.mydairy.fragment.AddEntry;
import com.mobilophilia.mydairy.fragment.DownloadFragment;
import com.mobilophilia.mydairy.fragment.EnterName;
import com.mobilophilia.mydairy.fragment.Entry;
import com.mobilophilia.mydairy.fragment.Expense;
import com.mobilophilia.mydairy.fragment.ReportFragment;
import com.mobilophilia.mydairy.fragment.SetPriceFragment;

public class MainActivity extends ActionBarActivity implements FragmentDrawer.FragmentDrawerListener {

    private static String TAG = MainActivity.class.getSimpleName();

    private Toolbar mToolbar;
    private FragmentDrawer drawerFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mToolbar = (Toolbar) findViewById(R.id.add_toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        drawerFragment = (FragmentDrawer) getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        drawerFragment.setUp(R.id.fragment_navigation_drawer, (DrawerLayout) findViewById(R.id.drawer_layout), mToolbar);
        drawerFragment.setDrawerListener(this);

        // display the first navigation drawer view on app launch
        displayView(0);
        getPermission();

        Util.createAppFolder(getAgentId());
    }

private String getAgentId(){
    SharedPreferences sharedPreferences = getSharedPreferences(Constants.SP_MY_DAIRY_MK, MODE_PRIVATE);
    String id = sharedPreferences.getString(Constants.SP_AGENT_ID_KEY, null);
   return id;
}



    @Override
    public void onDrawerItemSelected(View view, int position) {
        displayView(position);
    }

    private void displayView(int position) {
        Fragment fragment = null;
        String title = getString(R.string.app_name);
        switch (position) {
            case 0:
                fragment = new EnterName();
                title = getString(R.string.title_name);
                break;
            case 1:
                fragment = new Entry();
                title = getString(R.string.title_entry);
                break;
            case 2:
                fragment = new Expense();
                title = getString(R.string.title_expenses);
                break;
            case 3:
                fragment = new SetPriceFragment();
                title = getString(R.string.title_price);
                break;
            case 4:
                fragment = new DownloadFragment();
                title = getString(R.string.title_download);
                break;
            case 5:
                fragment = new ReportFragment();
                title = getString(R.string.title_report);
                break;
            case 7:
                logoutCleanUp();
                break;
            default:
                break;
        }

        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container_body, fragment);
            fragmentTransaction.commit();

            // set the toolbar title
            getSupportActionBar().setTitle(title);
        }
    }

    private void logoutCleanUp() {

        SharedPreferences sharedPref = getSharedPreferences(Constants.SP_MY_DAIRY_MK, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(Constants.SP_ID_KEY, 0);
        editor.putString(Constants.SP_AGENT_TOKEN_KEY, "");
        editor.putString(Constants.SP_AGENT_ID_KEY, "");
        editor.putString(Constants.SP_AGENT_NAME_KEY, "");
        editor.putString(Constants.SP_AGENT_PHONE_KEY, "");
        editor.putString(Constants.SP_AGENT_EMAIL_KEY, "");
        editor.putString(Constants.SP_AGENT_ADDRESS_KEY, "");
        editor.apply();

        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private void getPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.PERMISSION_CREATE_APP_FOLDER);
            }
        }
    }


    @Override
    public void onBackPressed() {
        if (currentFragment() instanceof AddEntry){

        }
        super.onBackPressed();
    }

    public Fragment currentFragment(){
        return getSupportFragmentManager().findFragmentById(R.id.fragment_place);
    }
}
