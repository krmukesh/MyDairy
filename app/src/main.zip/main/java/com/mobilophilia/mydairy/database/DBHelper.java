package com.mobilophilia.mydairy.database;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.mobilophilia.mydairy.common.Constants;
import com.mobilophilia.mydairy.common.Log;
import com.mobilophilia.mydairy.common.Util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by Hanji on 7/20/2017.
 */

public class DBHelper extends SQLiteOpenHelper {

    // Logcat tag
    private static final String LOG = "DBHelper";
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "myDairyAppMk";
    // Table Enter Names
    private static final String TABLE_ENTER_NANE = "tbEnterName";
    private static final String TABLE_SET_PRICE = "tbSetPrice";
    private static final String TABLE_MY_ENTRY = "tbMyEntry";
    private static final String TABLE_EXPENSES = "tbMyExpense";
    // Common column names
    private static final String KEY_ID = "id";
    private static final String KEY_AGENT_ID = "agentId";
    private static final String KEY_CREATED_AT = "created_at";
    // NOTES Table - column Names
    private static final String KEY_ENTER_CODE = "nameCode";
    private static final String KEY_ENTER_NAME = "enterName";
    private static final String KEY_ENTER_TYPE = "type";
    private static final String KEY_ENTER_PHONE = "phoneNo";
    // NOTES Table - column SetPrice
    private static final String KEY_LOW_FAT = "lowFat";
    private static final String KEY_HIGH_FAT = "highFat";
    private static final String KEY_LOW_SNF = "lowSnf";
    private static final String KEY_HIGH_SNF = "highSnf";
    private static final String KEY_START_PRICE = "startPrice";
    private static final String KEY_INTERVAL = "interval";
    private static final String KEY_TYPE = "type";
    private static final String KEY_TIME = "time";
    //Entry
    private static final String KEY_CLR = "entryClr";
    private static final String KEY_FAT = "entryFat";
    private static final String KEY_SNF = "entrySnf";
    private static final String KEY_LTR = "entryLtr";
    private static final String KEY_PRICE = "entryPrice";
    private static final String KEY_TOTAL = "entryTotal";

    //ExpenseList
    private static final String KEY_EXPENSE = "expense";


    private String mAgentID = "";

    // Table Create Statements
    private static final String CREATE_TABLE_ENTER_NAME = "CREATE TABLE "
            + TABLE_ENTER_NANE + "(" + KEY_ID + " INTEGER PRIMARY KEY,"
            + KEY_AGENT_ID + " TEXT,"
            + KEY_ENTER_CODE + " INTEGER,"
            + KEY_ENTER_NAME + " TEXT,"
            + KEY_ENTER_TYPE + " INTEGER,"
            + KEY_ENTER_PHONE + " TEXT,"
            + KEY_CREATED_AT + " DATETIME" + ")";

    // Table Create Statements setprice
    private static final String CREATE_TABLE_SET_PRICE = "CREATE TABLE "
            + TABLE_SET_PRICE + "(" + KEY_ID + " INTEGER PRIMARY KEY,"
            + KEY_AGENT_ID + " TEXT,"
            + KEY_LOW_FAT + " REAL,"
            + KEY_HIGH_FAT + " REAL,"
            + KEY_LOW_SNF + " REAL,"
            + KEY_HIGH_SNF + " REAL,"
            + KEY_START_PRICE + " REAL,"
            + KEY_INTERVAL + " REAL,"
            + KEY_TYPE + " INTEGER,"
            + KEY_TIME + " INTEGER,"
            + KEY_CREATED_AT + " DATETIME" + ")";

    // Table Create Statements My entry
    private static final String CREATE_TABLE_MY_ENTRY = "CREATE TABLE "
            + TABLE_MY_ENTRY + "(" + KEY_ID + " INTEGER PRIMARY KEY,"
            + KEY_AGENT_ID + " TEXT,"
            + KEY_ENTER_CODE + " INTEGER,"
            + KEY_CLR + " REAL,"
            + KEY_FAT + " REAL,"
            + KEY_SNF + " REAL,"
            + KEY_LTR + " REAL,"
            + KEY_PRICE + " REAL,"
            + KEY_TOTAL + " REAL,"
            + KEY_CREATED_AT + " DATETIME" + ")";


    // Table Create Statements My entry
    private static final String CREATE_TABLE_EXPENSES = "CREATE TABLE "
            + TABLE_EXPENSES + "(" + KEY_ID + " INTEGER PRIMARY KEY,"
            + KEY_AGENT_ID + " TEXT,"
            + KEY_ENTER_CODE + " INTEGER,"
            + KEY_EXPENSE + " REAL,"
            + KEY_CREATED_AT + " DATETIME" + ")";


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.SP_MY_DAIRY_MK, context.MODE_PRIVATE);
        String id = sharedPreferences.getString(Constants.SP_AGENT_ID_KEY, null);
        if (!Util.isEmpty(id)) {
            mAgentID = id;
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // creating required tables
        db.execSQL(CREATE_TABLE_ENTER_NAME);
        db.execSQL(CREATE_TABLE_SET_PRICE);
        db.execSQL(CREATE_TABLE_MY_ENTRY);
        db.execSQL(CREATE_TABLE_EXPENSES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // on upgrade drop older tables
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_ENTER_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_SET_PRICE);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_MY_ENTRY);
        db.execSQL("DROP TABLE IF EXISTS " + CREATE_TABLE_EXPENSES);
        // create new tables
        onCreate(db);
    }

    /**
     * Creating a EnterNameEntry
     */

    public long createEnterNameEntry(EnterNameEntry enterNameEntry) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_AGENT_ID, mAgentID);
        values.put(KEY_ENTER_CODE, enterNameEntry.getNameCode());
        values.put(KEY_ENTER_NAME, enterNameEntry.getEnterName());
        values.put(KEY_ENTER_TYPE, enterNameEntry.getType());
        values.put(KEY_ENTER_PHONE, enterNameEntry.getPhoneNo());
        values.put(KEY_CREATED_AT, getDateTime());
        // insert row
        long name_id = db.insert(TABLE_ENTER_NANE, null, values);
        return name_id;
    }


    /**
     * get single EnteredName
     */

    public EnterNameEntry getEnteredName(int enterCode) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_ENTER_NANE, null, KEY_AGENT_ID + " = ? AND " + KEY_ENTER_CODE + " = ?", new String[]{mAgentID, "" + enterCode}, null, null, null);
        EnterNameEntry ene = null;
        if (c != null && c.getCount() > 0) {
            c.moveToFirst();
            ene = new EnterNameEntry();
            ene.setId(c.getInt(c.getColumnIndex(KEY_ID)));
            ene.setNameCode((c.getInt(c.getColumnIndex(KEY_ENTER_CODE))));
            ene.setEnterName((c.getString(c.getColumnIndex(KEY_ENTER_NAME))));
            ene.setType((c.getInt(c.getColumnIndex(KEY_ENTER_TYPE))));
            ene.setPhoneNo((c.getString(c.getColumnIndex(KEY_ENTER_PHONE))));
            ene.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));
        }
        closeDB();
        return ene;
    }

    /**
     * getting all EnteredName
     */

    public List<EnterNameEntry> getAllEnteredDetails() {
        List<EnterNameEntry> arrayListName = new ArrayList<EnterNameEntry>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_ENTER_NANE, null, KEY_AGENT_ID + " = ?", new String[]{mAgentID}, null, null, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                EnterNameEntry ene = new EnterNameEntry();
                ene.setId(c.getInt(c.getColumnIndex(KEY_ID)));
                ene.setNameCode((c.getInt(c.getColumnIndex(KEY_ENTER_CODE))));
                ene.setEnterName((c.getString(c.getColumnIndex(KEY_ENTER_NAME))));
                ene.setType((c.getInt(c.getColumnIndex(KEY_ENTER_TYPE))));
                ene.setPhoneNo((c.getString(c.getColumnIndex(KEY_ENTER_PHONE))));
                ene.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));
                // adding to todo list
                arrayListName.add(ene);
            } while (c.moveToNext());
        }
        return arrayListName;
    }

    /**
     * getting Entered Name
     */

    public int getEnteredNameCount() {
        String countQuery = "SELECT  * FROM " + TABLE_ENTER_NANE + " WHERE " + KEY_AGENT_ID + " = " + mAgentID;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        // return count
        return count;
    }

    public int updateEnteredName(EnterNameEntry ene) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_ENTER_CODE, ene.getNameCode());
        values.put(KEY_ENTER_NAME, ene.getEnterName());
        values.put(KEY_ENTER_TYPE, ene.getType());
        values.put(KEY_ENTER_PHONE, ene.getPhoneNo());

        // updating row
        return db.update(TABLE_ENTER_NANE, values, KEY_ENTER_CODE + " = ?", new String[]{String.valueOf(ene.getNameCode())});
    }

    /**
     * Deleting a EnteredName
     */

    public void deleteEnteredName(int enteredCode) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_ENTER_NANE, KEY_ENTER_CODE + " = ?", new String[]{String.valueOf(enteredCode)});
    }

    public int getLastEnterCode() {
        int enterCode = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(TABLE_ENTER_NANE, new String[]{KEY_ENTER_CODE}, KEY_AGENT_ID + " = ?", new String[]{mAgentID}, null, null, KEY_ENTER_CODE + " DESC", "1");
        if (cursor.moveToFirst()) {
            String code = cursor.getString(cursor.getColumnIndex(KEY_ENTER_CODE));
            enterCode = Integer.parseInt(code.trim());
        }
        cursor.close();
        return enterCode;
    }

    /**
     * Creating a setpriceEntry
     */

    public long createSetPriceEntry(SetPriceEntry setPriceEntry) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_AGENT_ID, mAgentID);
        values.put(KEY_LOW_FAT, setPriceEntry.getLowFat());
        values.put(KEY_HIGH_FAT, setPriceEntry.getHighFat());
        values.put(KEY_LOW_SNF, setPriceEntry.getLowSnf());
        values.put(KEY_HIGH_SNF, setPriceEntry.getHighSnf());
        values.put(KEY_START_PRICE, setPriceEntry.getStartPrice());
        values.put(KEY_INTERVAL, setPriceEntry.getInterval());
        values.put(KEY_TYPE, setPriceEntry.getType());
        values.put(KEY_TIME, setPriceEntry.getTime());
        values.put(KEY_CREATED_AT, getDateTime());
        // insert row
        long name_id = db.insert(TABLE_SET_PRICE, null, values);
        return name_id;
    }

    public List<SetPriceEntry> getAllSetPrice() {
        List<SetPriceEntry> arrayListprice = new ArrayList<SetPriceEntry>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_SET_PRICE, null, KEY_AGENT_ID + " = ?", new String[]{mAgentID}, null, null, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                SetPriceEntry sep = new SetPriceEntry();
                sep.setId(c.getInt(c.getColumnIndex(KEY_ID)));
                sep.setLowFat((c.getDouble(c.getColumnIndex(KEY_LOW_FAT))));
                sep.setHighFat((c.getDouble(c.getColumnIndex(KEY_HIGH_FAT))));
                sep.setLowSnf((c.getDouble(c.getColumnIndex(KEY_LOW_SNF))));
                sep.setHighSnf((c.getDouble(c.getColumnIndex(KEY_HIGH_SNF))));
                sep.setStartPrice((c.getDouble(c.getColumnIndex(KEY_START_PRICE))));
                sep.setInterval((c.getDouble(c.getColumnIndex(KEY_INTERVAL))));
                sep.setType((c.getInt(c.getColumnIndex(KEY_TYPE))));
                sep.setTime((c.getInt(c.getColumnIndex(KEY_TIME))));
                sep.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));
                // adding to todo list
                arrayListprice.add(sep);
            } while (c.moveToNext());
        }
        return arrayListprice;
    }

    public SetPriceEntry getSetPriceFromId(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_SET_PRICE, null, KEY_AGENT_ID + " = ? AND " + KEY_ID + " = ?", new String[]{mAgentID, "" + id}, null, null, null);
        SetPriceEntry sep = null;

        if (c != null && c.getCount() > 0) {
            c.moveToFirst();
            sep = new SetPriceEntry();
            sep.setId(c.getInt(c.getColumnIndex(KEY_ID)));
            sep.setLowFat((c.getDouble(c.getColumnIndex(KEY_LOW_FAT))));
            sep.setHighFat((c.getDouble(c.getColumnIndex(KEY_HIGH_FAT))));
            sep.setLowSnf((c.getDouble(c.getColumnIndex(KEY_LOW_SNF))));
            sep.setHighSnf((c.getDouble(c.getColumnIndex(KEY_HIGH_SNF))));
            sep.setStartPrice((c.getDouble(c.getColumnIndex(KEY_START_PRICE))));
            sep.setInterval((c.getDouble(c.getColumnIndex(KEY_INTERVAL))));
            sep.setType((c.getInt(c.getColumnIndex(KEY_TYPE))));
            sep.setTime((c.getInt(c.getColumnIndex(KEY_TIME))));
            sep.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));
        }
        closeDB();
        return sep;
    }

    public int updatePriceWithId(SetPriceEntry spe) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_LOW_FAT, spe.getLowFat());
        values.put(KEY_HIGH_FAT, spe.getHighFat());
        values.put(KEY_LOW_SNF, spe.getLowSnf());
        values.put(KEY_HIGH_SNF, spe.getHighSnf());
        values.put(KEY_START_PRICE, spe.getStartPrice());
        values.put(KEY_INTERVAL, spe.getInterval());
        values.put(KEY_TYPE, spe.getType());
        values.put(KEY_TIME, spe.getTime());

        // updating row
        int up = db.update(TABLE_SET_PRICE, values, KEY_ID + " = ?", new String[]{String.valueOf(spe.getId())});
        return up;
    }


    public List<SetPriceEntry> getSetPriceTypeAndTime(int type, int time, String fat, String snf) {
        List<SetPriceEntry> arrayListprice = new ArrayList<SetPriceEntry>();
        String milkType = "" + type;
        String milkyTime = "" + time;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.query(TABLE_SET_PRICE, null, KEY_AGENT_ID + " = ? AND " + KEY_TYPE + " = ? AND " + KEY_TIME + " = ? AND " + KEY_LOW_FAT + " <= ? AND " + KEY_HIGH_FAT + " >= ? AND " + KEY_LOW_SNF + " <= ? AND " + KEY_HIGH_SNF + " >= ?", new String[]{mAgentID, milkType, milkyTime, fat, fat, snf, snf}, null, null, null);
        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                SetPriceEntry sep = new SetPriceEntry();
                sep.setId(c.getInt(c.getColumnIndex(KEY_ID)));
                sep.setLowFat((c.getDouble(c.getColumnIndex(KEY_LOW_FAT))));
                sep.setHighFat((c.getDouble(c.getColumnIndex(KEY_HIGH_FAT))));
                sep.setLowSnf((c.getDouble(c.getColumnIndex(KEY_LOW_SNF))));
                sep.setHighSnf((c.getDouble(c.getColumnIndex(KEY_HIGH_SNF))));
                sep.setStartPrice((c.getDouble(c.getColumnIndex(KEY_START_PRICE))));
                sep.setInterval((c.getDouble(c.getColumnIndex(KEY_INTERVAL))));
                sep.setType((c.getInt(c.getColumnIndex(KEY_TYPE))));
                sep.setTime((c.getInt(c.getColumnIndex(KEY_TIME))));
                sep.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));
                // adding to todo list
                arrayListprice.add(sep);
            } while (c.moveToNext());
        }
        return arrayListprice;
    }


    public List<SetPriceEntry> getPriceSetForGivenSNF(int type, int time, String snf) {
        List<SetPriceEntry> arrayListprice = new ArrayList<SetPriceEntry>();
        String milkType = "" + type;
        String milkyTime = "" + time;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.query(TABLE_SET_PRICE, null, KEY_AGENT_ID + " = ? AND " + KEY_TYPE + " = ? AND " + KEY_TIME + " = ? AND " + KEY_LOW_SNF + " <= ? AND " + KEY_HIGH_SNF + " >= ?", new String[]{mAgentID, milkType, milkyTime, snf, snf}, null, null, null);
        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                SetPriceEntry sep = new SetPriceEntry();
                sep.setId(c.getInt(c.getColumnIndex(KEY_ID)));
                sep.setLowFat((c.getDouble(c.getColumnIndex(KEY_LOW_FAT))));
                sep.setHighFat((c.getDouble(c.getColumnIndex(KEY_HIGH_FAT))));
                sep.setLowSnf((c.getDouble(c.getColumnIndex(KEY_LOW_SNF))));
                sep.setHighSnf((c.getDouble(c.getColumnIndex(KEY_HIGH_SNF))));
                sep.setStartPrice((c.getDouble(c.getColumnIndex(KEY_START_PRICE))));
                sep.setInterval((c.getDouble(c.getColumnIndex(KEY_INTERVAL))));
                sep.setType((c.getInt(c.getColumnIndex(KEY_TYPE))));
                sep.setTime((c.getInt(c.getColumnIndex(KEY_TIME))));
                sep.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));
                // adding to todo list
                arrayListprice.add(sep);
            } while (c.moveToNext());
        }
        return arrayListprice;
    }
//My entries
   /* public List<MyEntries> getAllEntries() {
        List<MyEntries> arrayMyEntries = new ArrayList<MyEntries>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_MY_ENTRY, null, KEY_AGENT_ID + " = ?", new String[]{mAgentID}, null, null, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                MyEntries myEBean = new MyEntries();
                myEBean.setId(c.getInt(c.getColumnIndex(KEY_ID)));
                myEBean.setCode((c.getInt(c.getColumnIndex(KEY_ENTER_CODE))));
                myEBean.setClr((c.getDouble(c.getColumnIndex(KEY_CLR))));
                myEBean.setFat((c.getDouble(c.getColumnIndex(KEY_FAT))));
                myEBean.setSnf((c.getDouble(c.getColumnIndex(KEY_SNF))));
                myEBean.setLtr((c.getDouble(c.getColumnIndex(KEY_LTR))));
                myEBean.setPrice((c.getDouble(c.getColumnIndex(KEY_PRICE))));
                myEBean.setTotal((c.getDouble(c.getColumnIndex(KEY_TOTAL))));
                myEBean.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));
                // adding to todo list
                arrayMyEntries.add(myEBean);
            } while (c.moveToNext());
        }
        return arrayMyEntries;
    }*/

    public List<MyEntries> getAllEntries() {
        List<MyEntries> arrayMyEntries = new ArrayList<MyEntries>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_MY_ENTRY, null, KEY_AGENT_ID + " = ?", new String[]{mAgentID}, null, null, KEY_CREATED_AT + " DESC", null);
        boolean isAdded = false;

        if (c.moveToFirst()) {
            do {
                Double grandTotla = 0d;
                MyEntries myEBean = new MyEntries();

                int code = c.getInt(c.getColumnIndex(KEY_ENTER_CODE));
                int id = c.getInt(c.getColumnIndex(KEY_ID));
                String codeStr = "" + code;
                isAdded = true;

                for (int i = 0; i < arrayMyEntries.size(); i++) {

                    if (arrayMyEntries.get(i).getCode() == code) {
                        isAdded = false;
                        break;
                    }
                }

                if (isAdded) {

                    String name = "";
                    Cursor nCursor = db.query(TABLE_ENTER_NANE, new String[]{KEY_ENTER_NAME}, KEY_AGENT_ID + " = ? AND " + KEY_ENTER_CODE + " = ?", new String[]{mAgentID, codeStr}, null, null, null);
                    if (nCursor.moveToFirst()) {
                        do {
                            name = nCursor.getString(nCursor.getColumnIndex(KEY_ENTER_NAME));
                        } while (nCursor.moveToNext());
                    }
                    Cursor pCursor = db.query(TABLE_MY_ENTRY, new String[]{KEY_TOTAL}, KEY_ENTER_CODE + " = ?", new String[]{codeStr}, null, null, null);
                    if (pCursor.moveToFirst()) {
                        do {
                            grandTotla = grandTotla + pCursor.getDouble(pCursor.getColumnIndex(KEY_TOTAL));
                        } while (pCursor.moveToNext());
                    }
                    myEBean.setId(id);
                    myEBean.setCode(code);
                    myEBean.setName(name);
                    myEBean.setTotal(grandTotla);
                    // adding to todo list
                    arrayMyEntries.add(myEBean);

                }


            } while (c.moveToNext());
        }
        return arrayMyEntries;
    }


    public List<MyEntries> getAllEntriesForReport() {
        List<MyEntries> arrayMyEntries = new ArrayList<MyEntries>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_MY_ENTRY, null, KEY_AGENT_ID + " = ?", new String[]{mAgentID}, null, null, KEY_CREATED_AT + " DESC", null);

        Double avgFat = 0d;
        Double avgSnf = 0d;
        Double avgPrice = 0d;
        Double totalLtr = 0d;
        Double grandTotla = 0d;

        if (c.moveToFirst()) {
            do {
                MyEntries myEBean = new MyEntries();

                int code = c.getInt(c.getColumnIndex(KEY_ENTER_CODE));
                int id = c.getInt(c.getColumnIndex(KEY_ID));
                String codeStr = "" + code;

                String name = "";
                Cursor nCursor = db.query(TABLE_ENTER_NANE, new String[]{KEY_ENTER_NAME}, KEY_AGENT_ID + " = ? AND " + KEY_ENTER_CODE + " = ?", new String[]{mAgentID, codeStr}, null, null, null);
                if (nCursor.moveToFirst()) {
                    do {
                        name = nCursor.getString(nCursor.getColumnIndex(KEY_ENTER_NAME));
                    } while (nCursor.moveToNext());
                }

                avgFat = avgFat + c.getDouble(c.getColumnIndex(KEY_FAT));
                avgSnf = avgSnf + c.getDouble(c.getColumnIndex(KEY_SNF));
                avgPrice = avgPrice + c.getDouble(c.getColumnIndex(KEY_PRICE));
                totalLtr = totalLtr + c.getDouble(c.getColumnIndex(KEY_LTR));
                grandTotla = grandTotla + c.getDouble(c.getColumnIndex(KEY_TOTAL));

                myEBean.avgFat = avgFat;
                myEBean.avgSnf = avgSnf;
                myEBean.avgPrice = avgPrice;
                myEBean.totalLtr = totalLtr;
                myEBean.grandPrice = grandTotla;

                myEBean.setId(id);
                myEBean.setCode(code);
                myEBean.setName(name);
                myEBean.setFat(c.getDouble(c.getColumnIndex(KEY_FAT)));
                myEBean.setSnf(c.getDouble(c.getColumnIndex(KEY_SNF)));
                myEBean.setPrice(c.getDouble(c.getColumnIndex(KEY_PRICE)));
                myEBean.setLtr(c.getDouble(c.getColumnIndex(KEY_LTR)));
                myEBean.setTotal(c.getDouble(c.getColumnIndex(KEY_TOTAL)));
                arrayMyEntries.add(myEBean);
            } while (c.moveToNext());
        }
        return arrayMyEntries;
    }


    public List<MyEntries> getListOfEntriesByCode(int code) {
        List<MyEntries> arrayMyEntries = new ArrayList<MyEntries>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_MY_ENTRY, null, KEY_AGENT_ID + " = ? AND " + KEY_ENTER_CODE + " = ?", new String[]{mAgentID, "" + code}, null, null, KEY_CREATED_AT + " DESC", null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                MyEntries myEBean = new MyEntries();

                myEBean.setId(c.getInt(c.getColumnIndex(KEY_ID)));
                myEBean.setCode(c.getInt(c.getColumnIndex(KEY_ENTER_CODE)));
                myEBean.setClr(c.getDouble(c.getColumnIndex(KEY_CLR)));
                myEBean.setFat(c.getDouble(c.getColumnIndex(KEY_FAT)));
                myEBean.setSnf(c.getDouble(c.getColumnIndex(KEY_SNF)));
                myEBean.setLtr(c.getDouble(c.getColumnIndex(KEY_LTR)));
                myEBean.setPrice(c.getDouble(c.getColumnIndex(KEY_PRICE)));
                myEBean.setTotal(c.getDouble(c.getColumnIndex(KEY_TOTAL)));

                arrayMyEntries.add(myEBean);

            } while (c.moveToNext());
        }
        return arrayMyEntries;
    }


    public long createEntry(MyEntries myEntries) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_AGENT_ID, mAgentID);
        values.put(KEY_ENTER_CODE, myEntries.getCode());
        values.put(KEY_CLR, myEntries.getClr());
        values.put(KEY_FAT, myEntries.getFat());
        values.put(KEY_SNF, myEntries.getSnf());
        values.put(KEY_LTR, myEntries.getLtr());
        values.put(KEY_PRICE, myEntries.getPrice());
        values.put(KEY_TOTAL, myEntries.getTotal());
        values.put(KEY_CREATED_AT, getDateTime());
        long name_id = db.insert(TABLE_MY_ENTRY, null, values);
        return name_id;
    }


    public long createExpense(ExpenseBean bean) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_AGENT_ID, mAgentID);
        values.put(KEY_ENTER_CODE, bean.getCode());
        values.put(KEY_EXPENSE, bean.getExpense());
        values.put(KEY_CREATED_AT, getDateTime());
        // insert row
        long name_id = db.insert(TABLE_EXPENSES, null, values);
        return name_id;
    }


    public List<ExpenseBean> getAllExpenses() {
        List<ExpenseBean> arrayMyEntries = new ArrayList<ExpenseBean>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_EXPENSES, null, KEY_AGENT_ID + " = ?", new String[]{mAgentID}, null, null, KEY_CREATED_AT + " DESC", null);
        if (c.moveToFirst()) {
            do {
                ExpenseBean myEBean = new ExpenseBean();

                int code = c.getInt(c.getColumnIndex(KEY_ENTER_CODE));
                String codeStr = "" + code;


                String name = "";
                Cursor nCursor = db.query(TABLE_ENTER_NANE, new String[]{KEY_ENTER_NAME}, KEY_AGENT_ID + " = ? AND " + KEY_ENTER_CODE + " = ?", new String[]{mAgentID, codeStr}, null, null, null);
                if (nCursor.moveToFirst()) {
                    do {
                        name = nCursor.getString(nCursor.getColumnIndex(KEY_ENTER_NAME));
                    } while (nCursor.moveToNext());
                }

                Double expense = c.getDouble(c.getColumnIndex(KEY_EXPENSE));
                myEBean.setCode(code);
                myEBean.setName(name);
                myEBean.setExpense(expense);
                arrayMyEntries.add(myEBean);

            } while (c.moveToNext());
        }
        return arrayMyEntries;
    }


    // closing database
    public void closeDB() {
        SQLiteDatabase db = this.getReadableDatabase();
        if (db != null && db.isOpen())
            db.close();
    }


    private String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }
}