package com.mobilophilia.mydairy.fragment;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.common.Constants;
import com.mobilophilia.mydairy.common.Util;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by yogen on 13-07-2017.
 */

public class ReportFragment extends Fragment implements View.OnClickListener {

    private TextView startDate;
    private TextView endDate;
    private TextView reportDate;
    private TextView tabDate;
    private TextView tabCode;
    private LinearLayout llTabDate;
    private LinearLayout llTabCode;

    private int mEndYear;
    private int mEndMonth;
    private int mEndDay;

    private int mStartYear;
    private int mStartMonth;
    private int mStartDay;
    private DatePickerDialog startDialog;
    private Button btnDwldReport;
    private EditText codeOne;
    private EditText codeTwo;
    private View rootView;
    private String errorMessage;

    public ReportFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_report, container, false);


        codeOne = (EditText) rootView.findViewById(R.id.edt_code_one);
        codeTwo = (EditText) rootView.findViewById(R.id.edt_code_second);

        startDate = (TextView) rootView.findViewById(R.id.input_date_one);
        startDate.setOnClickListener(this);
        endDate = (TextView) rootView.findViewById(R.id.input_date_second);
        endDate.setOnClickListener(this);

        tabDate = (TextView) rootView.findViewById(R.id.tab_date);
        tabDate.setOnClickListener(this);
        tabCode = (TextView) rootView.findViewById(R.id.tab_code);
        tabCode.setOnClickListener(this);

        reportDate = (TextView) rootView.findViewById(R.id.input_date_select);
        reportDate.setOnClickListener(this);

        llTabCode = (LinearLayout) rootView.findViewById(R.id.tap_code_layout);
        llTabDate = (LinearLayout) rootView.findViewById(R.id.tap_date_layout);


        btnDwldReport = (Button) rootView.findViewById(R.id.btn_download_report);
        btnDwldReport.setOnClickListener(this);

        Calendar c = Calendar.getInstance();
        mStartYear = c.get(Calendar.YEAR);
        mStartMonth = c.get(Calendar.MONTH);
        mStartDay = c.get(Calendar.DAY_OF_MONTH);

        Util.iSenableButton(getActivity(), btnDwldReport, false);
        changeTabView(0);
        Util.setBlankAndIsEnable(codeOne, true);
        Util.setBlankAndIsEnable(codeTwo, false);
        Util.setTVAndIsEnable(startDate, false);
        Util.setTVAndIsEnable(endDate, false);

        codeOne.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void afterTextChanged(Editable s) {
                String codeInterval1st = codeOne.getText().toString().trim();
                if (!Util.isEmpty(codeInterval1st)) {
                    Double code = Double.parseDouble(codeInterval1st);
                    if (code>=1) {
                        Util.setBlankAndIsEnable(codeTwo, true);
                        Util.setTVAndIsEnable(startDate, false);
                        Util.setTVAndIsEnable(endDate, false);
                        Util.iSenableButton(getActivity(), btnDwldReport, false);
                    } else {
                        Util.setBlankAndIsEnable(codeTwo, false);
                        Util.setTVAndIsEnable(startDate, false);
                        Util.setTVAndIsEnable(endDate, false);
                        Util.iSenableButton(getActivity(), btnDwldReport, false);
                    }
                } else {
                    Util.setBlankAndIsEnable(codeTwo, false);
                    Util.setTVAndIsEnable(startDate, false);
                    Util.setTVAndIsEnable(endDate, false);
                    Util.iSenableButton(getActivity(), btnDwldReport, false);
                    errorMessage = Constants.ERROR_VALIDATION_CODE;
                    errorMessage(errorMessage);
                }
            }
        });


        codeTwo.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void afterTextChanged(Editable s) {
                String codeInterval2nd = codeTwo.getText().toString().trim();
                if (!Util.isEmpty(codeInterval2nd)) {
                    Double code = Double.parseDouble(codeInterval2nd);
                    if (code >= 1) {
                        Util.setTVAndIsEnable(startDate, true);
                        Util.setTVAndIsEnable(endDate, false);
                        Util.iSenableButton(getActivity(), btnDwldReport, false);
                    } else {
                        Util.setTVAndIsEnable(startDate, false);
                        Util.setTVAndIsEnable(endDate, false);
                        Util.iSenableButton(getActivity(), btnDwldReport, false);
                    }
                } else {
                    Util.setTVAndIsEnable(startDate, false);
                    Util.setTVAndIsEnable(endDate, false);
                    Util.iSenableButton(getActivity(), btnDwldReport, false);
                    errorMessage = Constants.ERROR_VALIDATION_CODE;
                    errorMessage(errorMessage);
                }
            }
        });


        // Inflate the layout for this fragment
        return rootView;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId() /*to get clicked view id**/) {
            case R.id.input_date_one:
                showCurrentDate(startDateSetListener);
                break;
            case R.id.input_date_second:
                showEndDate(endDateSetListener);
                break;
            case R.id.tab_date:
                changeTabView(0);
                break;
            case R.id.tab_code:
                changeTabView(1);
                break;
            case R.id.input_date_select:
                getReportDate(reportDateSetListener);
                break;
            case R.id.btn_download_report:

                break;
            default:
                break;
        }
    }

    private void errorMessage(String message) {
        Snackbar.make(rootView, "" + message, Snackbar.LENGTH_LONG).show();
    }

    private void showCurrentDate(DatePickerDialog.OnDateSetListener dateListenee) {
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        startDialog = new DatePickerDialog(getActivity(), dateListenee, year, month, day);
        startDialog.getDatePicker().setMaxDate(new Date().getTime());
        startDialog.show();
    }

    private void showEndDate(DatePickerDialog.OnDateSetListener dateListenee) {
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog dialog = new DatePickerDialog(getActivity(), dateListenee, year, month, day);
        dialog.getDatePicker().setMaxDate(new Date().getTime());
        Calendar calendar = Calendar.getInstance();
        calendar.set(startDialog.getDatePicker().getYear(), startDialog.getDatePicker().getMonth(), startDialog.getDatePicker().getDayOfMonth(), 0, 0, 0);
        long startTime = calendar.getTimeInMillis();
        dialog.getDatePicker().setMaxDate(new Date().getTime());
        dialog.getDatePicker().setMinDate(startTime);
        dialog.show();
    }

    private void getReportDate(DatePickerDialog.OnDateSetListener dateListenee) {
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog reporDialog = new DatePickerDialog(getActivity(), dateListenee, year, month, day);
        reporDialog.getDatePicker().setMaxDate(new Date().getTime());
        reporDialog.show();
    }

    private void changeTabView(int t) {
        if (t == 0) {
            tabDate.setTextColor(getResources().getColor(R.color.white));
            tabCode.setTextColor(getResources().getColor(R.color.black_overlay));
            tabDate.setBackgroundDrawable(getResources().getDrawable(R.drawable.circular_left_blue));
            tabCode.setBackgroundDrawable(getResources().getDrawable(R.drawable.circular_right_white));
            llTabDate.setVisibility(View.VISIBLE);
            llTabCode.setVisibility(View.GONE);
            Util.iSenableButton(getActivity(), btnDwldReport, false);
            Util.setTextBlank(reportDate);
        } else if (t == 1) {
            tabDate.setTextColor(getResources().getColor(R.color.black_overlay));
            tabCode.setTextColor(getResources().getColor(R.color.white));
            tabDate.setBackgroundDrawable(getResources().getDrawable(R.drawable.circular_left_white));
            tabCode.setBackgroundDrawable(getResources().getDrawable(R.drawable.circular_right_blue));
            llTabDate.setVisibility(View.GONE);
            llTabCode.setVisibility(View.VISIBLE);
            Util.iSenableButton(getActivity(), btnDwldReport, false);
            Util.setTextBlank(reportDate);
        }
    }


    private DatePickerDialog.OnDateSetListener startDateSetListener = new
            DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    mStartYear = year;
                    mStartMonth = monthOfYear;
                    mStartDay = dayOfMonth;
                    updateDisplay();
                }
            };


    private DatePickerDialog.OnDateSetListener endDateSetListener = new
            DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    mEndYear = year;
                    mEndMonth = monthOfYear;
                    mEndDay = dayOfMonth;
                    updateEndDate();
                }
            };

    private DatePickerDialog.OnDateSetListener reportDateSetListener = new
            DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    mStartYear = year;
                    mStartMonth = monthOfYear;
                    mStartDay = dayOfMonth;
                    updateReportDateDisplay();
                }
            };


    private void updateDisplay() {
        mStartMonth = mStartMonth + 1;
        String Dates = (mStartDay < 10 ? ("0" + mStartDay) : (mStartDay) + "-" + (mStartMonth < 10 ? ("0" + mStartMonth) : (mStartMonth)) + "-" + mStartYear);
        startDate.setText(Dates);
        Util.setTVAndIsEnable(endDate, true);
        Util.iSenableButton(getActivity(), btnDwldReport, false);
    }

    private void updateReportDateDisplay() {
        mStartMonth = mStartMonth + 1;
        String Dates = (mStartDay < 10 ? ("0" + mStartDay) : (mStartDay) + "-" + (mStartMonth < 10 ? ("0" + mStartMonth) : (mStartMonth)) + "-" + mStartYear);
        reportDate.setText(Dates);
        Util.iSenableButton(getActivity(), btnDwldReport, true);
    }

    private void updateEndDate() {
        mEndMonth = mEndMonth + 1;
        String Dates = (mEndDay < 10 ? ("0" + mEndDay) : (mEndDay) + "-" + (mEndMonth < 10 ? ("0" + mEndMonth) : (mEndMonth)) + "-" + mEndYear);
        endDate.setText(Dates);
        Util.iSenableButton(getActivity(), btnDwldReport, true);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
