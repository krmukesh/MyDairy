package com.mobilophilia.mydairy.drawer;

/**
 * Created by yogen on 12-07-2017.
 */

public class NavDrawerItem {
    private String title;
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}