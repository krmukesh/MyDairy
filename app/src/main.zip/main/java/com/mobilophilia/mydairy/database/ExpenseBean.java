package com.mobilophilia.mydairy.database;

/**
 * Created by mukesh on 16/08/17.
 */

public class ExpenseBean {
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public Double getExpense() {
        return expense;
    }

    public void setExpense(Double expense) {
        this.expense = expense;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    private int id;
    private int code;
    private Double expense;
    private String createdAt;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
