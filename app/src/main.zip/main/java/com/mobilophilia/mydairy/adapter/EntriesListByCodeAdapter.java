package com.mobilophilia.mydairy.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.database.MyEntries;

import java.util.List;

/**
 * Created by mukesh on 04/08/17.
 */

public class EntriesListByCodeAdapter extends RecyclerView.Adapter<EntriesListByCodeAdapter.MyViewHolder> {

    private List<MyEntries> entries;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView customerCode, customerName, total;

        public MyViewHolder(View view) {
            super(view);
            customerCode = (TextView) view.findViewById(R.id.txt_expenses);
            total = (TextView) view.findViewById(R.id.total_price_ex);
        }
    }

    public EntriesListByCodeAdapter(List<MyEntries> entriesList) {
        this.entries = entriesList;
    }

    @Override
    public EntriesListByCodeAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_entries_by_code, parent, false);

        return new EntriesListByCodeAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(EntriesListByCodeAdapter.MyViewHolder holder, int position) {
        MyEntries entry = entries.get(position);
        holder.customerCode.setText("Code: " + entry.getCode()+" CLR: "+entry.getClr()+" FAT: "+entry.getFat()+"\nSNF: "+entry.getSnf()+" LTR: "+entry.getLtr()+" Price: "+entry.getPrice());
        holder.total.setText("Total:" + entry.getTotal());
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }
}