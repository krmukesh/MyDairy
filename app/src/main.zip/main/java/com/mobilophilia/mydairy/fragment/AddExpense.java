package com.mobilophilia.mydairy.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.common.Constants;
import com.mobilophilia.mydairy.common.MessageEvent;
import com.mobilophilia.mydairy.common.Util;
import com.mobilophilia.mydairy.database.DBHelper;
import com.mobilophilia.mydairy.database.EnterNameEntry;
import com.mobilophilia.mydairy.database.ExpenseBean;
import com.mobilophilia.mydairy.manager.AppManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Created by mukesh on 16/08/17.
 */

public class AddExpense extends Fragment implements View.OnClickListener {
    private View rootView;
    private DBHelper dbHelper;
    private TextView customerName;
    private TextView customerPhone;
    private EditText inputCode;
    private EditText inPutExpenses;
    private String errorMessage;
    private Button btnSubmit;

    public AddExpense() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_add_expense, container, false);
        dbHelper = new DBHelper(getActivity());
        customerName = (TextView) rootView.findViewById(R.id.customer_name);
        customerPhone = (TextView) rootView.findViewById(R.id.customer_phone);
        inputCode = (EditText) rootView.findViewById(R.id.input_code);
        inPutExpenses = (EditText) rootView.findViewById(R.id.input_expenses);
        inPutExpenses.setEnabled(false);

        btnSubmit = (Button) rootView.findViewById(R.id.btn_expeanses);
        btnSubmit.setOnClickListener(this);

        Util.setBlankAndIsEnable(inPutExpenses, false);
        Util.iSenableButton(getActivity(), btnSubmit, false);

        inputCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!Util.isEmpty(inputCode.getText().toString())) {
                    EnterNameEntry ene = dbHelper.getEnteredName(Integer.parseInt(inputCode.getText().toString()));
                    if (ene != null) {
                        customerName.setText(ene.getEnterName());
                        customerPhone.setText(ene.getPhoneNo());
                        Util.setBlankAndIsEnable(inPutExpenses, true);
                    } else {
                        Util.setTextBlank(customerName);
                        Util.setTextBlank(customerPhone);
                        Util.setBlankAndIsEnable(inPutExpenses, false);
                        errorMessage = Constants.ERROR_CODE_INVALID;
                        errorMessage(errorMessage);
                    }
                } else {
                    Util.setTextBlank(customerName);
                    Util.setTextBlank(customerPhone);
                    Util.setBlankAndIsEnable(inPutExpenses, false);
                    errorMessage = Constants.ERROR_CODE_INVALID_BLANK;
                    errorMessage(errorMessage);
                }
                // TODO Auto-generated method stub
            }
        });


        inPutExpenses.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void afterTextChanged(Editable s) {
                String expenses = inPutExpenses.getText().toString().trim();

                if (!Util.isEmpty(expenses)) {
                    Double exp = Double.parseDouble(expenses);
                    if (exp > 0) {
                        Util.iSenableButton(getActivity(), btnSubmit, true);
                    } else {
                        Util.iSenableButton(getActivity(), btnSubmit, false);
                        errorMessage = Constants.ERROR_EXPENSES;
                        errorMessage(errorMessage);
                    }
                } else {
                    Util.iSenableButton(getActivity(), btnSubmit, false);
                    errorMessage = Constants.ERROR_EXPENSES;
                    errorMessage(errorMessage);
                }
            }
        });


        // Inflate the layout for this fragment
        return rootView;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId() /*to get clicked view id**/) {
            case R.id.btn_expeanses:
                submitExpenses();
                break;
            default:
                break;
        }
    }

    private void submitExpenses() {
        String code = inputCode.getText().toString().trim();
        String expenses = inPutExpenses.getText().toString().trim();
        ExpenseBean bean = new ExpenseBean();
        bean.setCode(Integer.parseInt(code));
        bean.setExpense(Double.parseDouble(expenses));


        DBHelper dbHelper = new DBHelper(getActivity());
        dbHelper.createExpense(bean);

        reSetValues();

       // Util.launchBarDialog(getActivity(), Constants.PROGRESS_DIALOG_EXPENSES);
       // AppManager.getInstance().getExpenseManager().saveEXpenes(getActivity(), code, expenses);
    }

   /* private boolean feildValidation() {
        boolean rtn = true;
        if (Util.isEmpty(inputCode.getText().toString())) {
            errorMessage = Constants.ERROR_VALIDATION_CODE;
            rtn = false;
        } else if (Util.isEmpty(inPutExpenses.getText().toString())) {
            errorMessage = Constants.ERROR_VALIDATION_CLR;
            rtn = false;
        }
        return rtn;
    }*/

    private void errorMessage(String message) {
        Snackbar.make(rootView, "" + message, Snackbar.LENGTH_LONG).show();
    }

    private void reSetValues() {
        Util.setBlankAndIsEnable(inputCode, true);
        Util.setBlankAndIsEnable(inPutExpenses, false);
        Util.iSenableButton(getActivity(), btnSubmit, false);
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MessageEvent event) {
        switch (event.getType()) {
            case MessageEvent.EXPENSES_SUCCESS:
                Util.dismissBarDialog();
                reSetValues();
                Util.launchMessageDialog(getActivity(), "" + event.getMessage());
                break;
            case MessageEvent.EXPENSES_FAILURE:
                Util.dismissBarDialog();
                Util.launchMessageDialog(getActivity(), "" + event.getMessage());
                break;

            case MessageEvent.NETWORK_TIME_OUT:
                Util.dismissBarDialog();
                Toast.makeText(getActivity(), getString(R.string.network_timeout_error), Toast.LENGTH_LONG).show();
                break;

            case MessageEvent.SERVER_ERROR_OCCURRED:
                Util.dismissBarDialog();
                Toast.makeText(getActivity(), getString(R.string.server_error), Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
