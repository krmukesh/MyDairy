package com.mobilophilia.mydairy.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobilophilia.mydairy.R;
import com.mobilophilia.mydairy.adapter.CustomerListAdapter;
import com.mobilophilia.mydairy.database.DBHelper;
import com.mobilophilia.mydairy.database.EnterNameEntry;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mukesh on 16/08/17.
 */

public class NameList extends Fragment {

    private List<EnterNameEntry> customerList = new ArrayList<>();
    private RecyclerView recyclerView;
    private CustomerListAdapter mAdapter;
    private DBHelper dbHelper;

    public NameList() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_customer_list, container, false);

        dbHelper = new DBHelper(getActivity());
        customerList.clear();
        customerList = dbHelper.getAllEnteredDetails();

        recyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view_customer);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        mAdapter = new CustomerListAdapter(customerList);
        recyclerView.setAdapter(mAdapter);
        // Inflate the layout for this fragment
        return rootView;
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}

