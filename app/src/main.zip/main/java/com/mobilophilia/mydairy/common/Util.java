package com.mobilophilia.mydairy.common;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Environment;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.mobilophilia.mydairy.R;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by yogen on 18-07-2017.
 */

public class Util {


    public static ProgressDialog barProgressDialog;
    public static Dialog dialog;

    public static void launchBarDialog(Activity activity, String msg) {
        dismissBarDialog();
        dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.progress_dialog);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        Window window = dialog.getWindow();
        lp.copyFrom(window.getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        window.setAttributes(lp);

        TextView text = (TextView) dialog.findViewById(R.id.dia_msg);
        text.setText(msg);
        dialog.show();
    }




    public static void launchMessageDialog(Activity activity, String msg) {

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_message);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        Window window = dialog.getWindow();
        lp.copyFrom(window.getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        window.setAttributes(lp);

        TextView text = (TextView) dialog.findViewById(R.id.dia_msg);
        text.setText(msg);

        Button btnOk = (Button) dialog.findViewById(R.id.btn_ok);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    public static void dismissBarDialog() {
        try {
            if (dialog.isShowing())
                dialog.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isEmpty(String str) {
        return str == null || str.equalsIgnoreCase("null")
                || str.equalsIgnoreCase("") || str.length() < 1 || str.equalsIgnoreCase(" ");
    }


    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static boolean isValidPhoneNumber(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            if (target.length() < 6 || target.length() > 13) {
                return false;
            } else {
                return android.util.Patterns.PHONE.matcher(target).matches();
            }
        }
    }

    public static void validatioMessage(View view, String message) {
        Snackbar.make(view, "" + message, Snackbar.LENGTH_LONG).show();
    }


    public static Double convertIntoSNF(Double clr, Double fat) {
        return ((clr / 4) + (0.21 * fat) + 0.36);
    }


    public static String createAppFolder(String agentId) {
         String path ="";
         File dir;

        path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/MyDairyApp/"+agentId;
        dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return path;
    }


    public static int getTime() {
        int shift = 0;
        Calendar calander = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("a");
        String time = simpleDateFormat.format(calander.getTime());
       /* SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm:ss a");
        String time = simpleDateFormat.format(calander.getTime());*/
        if (time.equalsIgnoreCase("AM")) {
            shift = 0;
        } else {
            shift = 1;
        }
        return shift;
    }

    public static Double getPrice(Double basePrice, Double inputFat, Double calSnf, Double intervl, Double lowFat, Double highFat, Double lowSnf) {
        Double price = 0d;
        Double cP11 = ((inputFat - lowFat) * 10);
        Double cP12 = (intervl * Math.round(cP11));

        Double cP21 = ((calSnf - lowSnf) * 10);
        Long cP22 = Math.round(cP21);
        ;
        Double cP31 = ((highFat - lowFat) * 10);
        Long cP311 = Math.round(cP31);

        Double cP32 = (intervl * (cP311 + 1));

        price = basePrice + cP12 + (cP22 * cP32);

        return price;
    }

    public static void iSenableButton(Context con, Button button, boolean isEnable) {

        if (isEnable) {
            button.setEnabled(isEnable);
            button.setTextColor(con.getResources().getColor(R.color.con_theme));
            button.setBackground(con.getResources().getDrawable(R.drawable.border_blue));
        } else {
            button.setEnabled(isEnable);
            button.setTextColor(con.getResources().getColor(R.color.black_overlay));
            button.setBackground(con.getResources().getDrawable(R.drawable.border_gray));
        }
        //button.setBackground(con.getResources().getDrawable(R.drawable.border_blue));
    }

    public static void setBlankAndIsEnable(EditText editBOX, boolean isEnable) {
        if (editBOX.getText().toString().trim().length() > 0) {
            editBOX.setText("");
        }
        editBOX.setEnabled(isEnable);
    }

    public static void setTextBlank(TextView textView) {
        textView.setText("");
    }

    public static void setTVAndIsEnable(TextView textView, boolean isEnable) {
        if (isEnable) {
            textView.setEnabled(isEnable);
        } else {
            textView.setEnabled(isEnable);
        }
        textView.setText("");
    }

}
